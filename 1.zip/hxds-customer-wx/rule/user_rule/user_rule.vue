<template>
	<view class="page">
		<view class="title">总则</view>
		<view class="section">规则的目的和任务</view>
		<view class="desc">本规则基于打击恶意乘客， 维护司机人身财产安全及平台运行秩序的目的，结合平台恶意乘客现象及处理经验，进行制定。</view>
		<view class="section">适用范围</view>
		<view class="desc">本规则适用于通过华夏代驾APP、华夏代驾小程序等途径使用华夏代驾功能及服务的全部乘客。</view>
		<view class="section">基本原则</view>
		<view class="desc">平等原则：对于任何乘客违规，在规则面前一律平等，任何等级、消费记录等因素均不影响规则的判定。</view>
		<view class="desc">
			法律原则
			：对于乘客在使用滴滴代驾的过程中发生了涉嫌违反国家法律、行政法规、部门规章及相关规则性文件的规定行为的，平台有权对该乘客账号进行管控，本规则已有规定的，适用本规则
			;本规则尚无规定的，平台有权在合法合理的范围内酌情处理。同时将该案件移至公安机关处理 。
		</view>
		<view class="section">处罚形式</view>
		<view class="desc">限制账号使用 ：限制违规人使用华夏代驾发单功能的权利，限制过程中该账号仍可登陆查看账号信息，但无法通过华夏代驾发单并享受代驾服务。</view>
		<view class="desc">溯及力 ：在本规则进行变更时，规则对于行为的溯及力遵循“从旧兼从轻”原则 。</view>
		<view class="title">分则</view>
		<view class="section">第一章 损害平台管理秩序</view>
		<view class="desc">
			第一节 黑单空号
			<br />
			无真实代驾需求的乘客故意频繁发单，并最终订单被取消，影响平台派单秩序的，对乘客账号处以限制使用6个月的处罚。手段恶劣、行为密集或多次触犯的永久封禁乘客账号。
		</view>
		<view class="desc">
			第二节 司乘联合刷单
			<br />
			滴滴代驾乘客同滴滴代驾司机串通虚构订单事实以进行虚假交易的，对乘客账号处以限制使用6个月的处罚。
		</view>
		<view class="desc">
			第三节 产品推销
			<br />
			无真实代驾需求的乘客在滴滴代驾平台进行发单，向滴滴代驾司机进行商品或服务的推销，并最终订单被取消的，对乘客账号处以限制使用6个月的处罚，其中推销平台不认可的第三方软件的，永久封禁乘客账号。
		</view>
		<view class="section">第二章 损害司机人身财产</view>
		<view class="desc">
			第一节 恶意差评投诉
			<br />
			滴滴代驾乘客未公正客观使用订单评价功能，对代驾服务进行大量频繁恶意差评，或议价无果后投诉滴滴代驾司机，影响司机代驾工作的，对乘客账号处以限制使用30天的处罚。恶意捏造事实对司机进行重大投诉，如恶意投诉司机性骚扰、殴打或其他犯罪行为的，对乘客账号处以限制使用6个月的处罚。手段恶劣、后果严重的，永久封禁乘客账号。
		</view>
		<view class="desc">
			第二节 辱骂殴打司机
			<br />
			滴滴代驾乘客在享受代驾服务过程中，故意对滴滴代驾司机进行辱骂或殴打，侵害司机人身安全的，对乘客账号处以限制使用的处罚，辱骂的限制使用30天，殴打的限制使用6个月。情节严重的，永久封禁乘客账号。
		</view>
		<view class="desc">
			第三节 强制结束代驾
			<br />
			滴滴代驾乘客在享受代驾服务过程中，无正当理由在高速路、快速路及高架等危险路段强制结束代驾，或在普通路段强制结束代驾并造成严重后果的，永久封禁乘客账号。
		</view>
		<view class="desc">
			第四节 威胁胁迫
			<br />
			滴滴代驾乘客在使用滴滴代驾的过程中，故意对滴滴代驾司机进行威胁，向司机提出免单、私人优惠或其他不合理要求，侵害司机应得利益的，对乘客账号处以限制使用30天的处罚，并归还司机损失，否则限制账号使用直至其归还。
		</view>
		<view class="desc">
			第五节 性骚扰
			<br />
			滴滴代驾乘客在享受代驾服务过程中，对滴滴代驾司机进行性骚扰行为，对司机人身财产或精神造成伤害的，对乘客账号处限制使用的处罚，言语上骚扰的限制6个月，存在肢体触碰性骚扰的限制12个月。情节严重的，永久封禁乘客账号。
		</view>
		<view class="desc">性骚扰指为了满足性方面欲望，违背受害人意志，向受害人实施带性暗示的言语动作的行为，特别是肢体碰触受害者性别特征部位。</view>
		<view class="desc">
			第六节 抢劫诈骗
			<br />
			滴滴代驾乘客在使用代驾服务过程中，通过隐瞒、欺骗或暴力威胁的手段，对滴滴代驾司机进行抢劫诈骗并造成司机财产损失的，永久封禁乘客账号。
		</view>
		<u-top-tips ref="uTips"></u-top-tips>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	methods: {},
	onShow: function() {
		let that = this;
		//定时刷新消息
		uni.$on('message', function() {
			that.refreshMessage(that);
		});

		uni.$on('showMessageTip', function(lastRows) {
			that.$refs.uTips.show({
				title: `最新收到${lastRows}条消息通知`,
				type: 'success',
				duration: '2300'
			});
		});
	},
	onHide: function() {
		uni.$off('message');
		uni.$off('showMessageTip');
	}
};
</script>

<style lang="less">
@import url('user_rule.less');
</style>
