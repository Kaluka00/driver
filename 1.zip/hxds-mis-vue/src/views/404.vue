<template>
	<div class="content"><div class="title">诶呀，你访问的页面不存在</div></div>
</template>

<script></script>

<style lang="less" scoped="scoped">
.content {
	text-align: center;
	height: 100%;
	padding-top: 200px;
	background-image: url(../assets/404.jpg);
	background-size: cover;
	background-position: center;

	.title {
		font-family: '微软雅黑';
		font-size: 28px;
		color: #888;
	}
}
</style>
